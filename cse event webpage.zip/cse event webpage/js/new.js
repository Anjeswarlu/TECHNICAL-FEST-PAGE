function fun(){
    var a=document.getElementById("con");
    a.style.color="var(--secondary-color)";
      var b=document.getElementById("con4");
      b.style.color="white";
}
function fun1(){
    var a=document.getElementById("con");
    a.style.color="white";
}
function fun2(){
    var a=document.getElementById("con");
    a.style.color="white";
}
function fun3(){
    var a=document.getElementById("con");
    a.style.color="white";
}
function fun4(){
    var a=document.getElementById("con");
    var b=document.getElementById("con4");
    a.style.color="white";
}